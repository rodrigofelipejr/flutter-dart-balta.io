class ContactModel {
  String id;
  String name;
  String email;
  String phone;

  ContactModel({
    this.id,
    this.name,
    this.email,
    this.phone,
  });
}
